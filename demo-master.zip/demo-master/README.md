SpringBoot demo project for rancher pipeline learning.
